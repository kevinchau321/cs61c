#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include "lexer.h"
#include "util/util.h"
#include "parser.h"
#include <string.h>

#define INIT_BUFFER_SIZE 256

void init_lex(lexer *luthor) {
    luthor->file = NULL;
    luthor->buffer = NULL;
    luthor->type = token_SENTINEL;
    luthor->buff_len = 0;
}

void open_file(lexer *lex, char *filename) {
    if (lex) {
	lex->file = fopen(filename, "r");
	if (!lex->file) {
	    fatal_error("Could not read input file.\n");
	}
	lex->buff_len = INIT_BUFFER_SIZE;
	lex->buffer = safe_calloc(INIT_BUFFER_SIZE * sizeof(char));
    }
}

void close_file(lexer *lex) {
    if (lex) {
	fclose(lex->file);
	free(lex->buffer);
	lex->buff_len = 0;
	lex->buffer = NULL;
    }
}

void read_token(lexer *lex) {
    /* TODO: Implement me. */
    /* HINT: fgetc() and ungetc() could be pretty useful here. */
    lex->buffer = (char*) safe_realloc(lex->buffer, INIT_BUFFER_SIZE*sizeof(char));             ///consider using memset
    char* word = malloc(INIT_BUFFER_SIZE*sizeof(char));
    lex->buff_len=0;
    int maxbuff = INIT_BUFFER_SIZE;

    if (word == NULL){
        printf("allocation error\n");
    }
    char c;
    c = fgetc(lex->file);

    while (c=='\n' || c=='\t' || c== ' ') {
        c=fgetc(lex->file);     //move through white space until next char
    }

    if (c == '('){  //found non white char
        *word=c;
        lex->type = token_OPEN_PAREN;
        lex->buff_len++;
    } else if (c == ')'){
        *word = c;
        lex->type = token_CLOSE_PAREN;
        lex->buff_len++;
    } else if (c == EOF){
        *word = c;
        lex->type = token_END;
        lex->buff_len++;
    } else if (c > 47 && c < 58 ) {    //first character is a digit, so type is int
        lex->type = token_INT;
        while (c!='\n' && c!='\t' && c!= ' ' ){
            if (c<48 || c >57) {
                fprintf(stderr, "Lexing Error: invalid integer token\n");
                exit(1);
            } else {
                if (lex->buff_len >= maxbuff) {
                    maxbuff = maxbuff*2;
                    word = (char*) safe_realloc(word, maxbuff*sizeof(char));
                    lex->buffer = (char*) safe_realloc(lex->buffer, maxbuff*sizeof(char));
                }
                *(word+lex->buff_len)=c;
                lex->buff_len++;
                c=fgetc(lex->file);
            }
        }

    } else if (c=='\"') { //token is a LIFC string
        *(word)=c;
        lex->buff_len++;
        while ((c=fgetc(lex->file))!='\"') {
           if (lex->buff_len >= maxbuff) {
                maxbuff=maxbuff*2;
                word = (char*) safe_realloc(word, maxbuff*sizeof(char));
                lex->buffer = (char*) safe_realloc(lex->buffer, maxbuff*sizeof(char));
           } 
            *(word+lex->buff_len) = c;
            lex->buff_len++;
        }
        if (lex->buff_len >= maxbuff) { //store last quote
                maxbuff=maxbuff*2;
                word = (char*) safe_realloc(word, maxbuff*sizeof(char));
                lex->buffer = (char*) safe_realloc(lex->buffer, maxbuff*sizeof(char));
        } 
        *(word+lex->buff_len) = c;
        lex->buff_len++;
        lex->type = token_STRING;

    } else {        //token is a string keyword or name
        while (c!='\n' && c!='\t' && c!= ' ' ){
            if (lex->buff_len >= maxbuff) {
                maxbuff=maxbuff*2;    //double buffer
                word = (char*) safe_realloc(word, maxbuff*sizeof(char));
                lex->buffer = (char*) safe_realloc(lex->buffer, maxbuff*sizeof(char));
            } 
            *(word+lex->buff_len) = c;
            lex->buff_len++;
            c=fgetc(lex->file);
            
        }

        if (!strcmp(word,"+") || !strcmp(word,"-") || !strcmp(word,"*") || !strcmp(word,"/")){
            lex->type = token_KEYWORD;  //basic arithmetic
        } else if (!strcmp(word, "and") || !strcmp(word,"or") || !strcmp(word,"lt") || !strcmp(word,"eq") || !strcmp(word,"function") || !strcmp(word,"struct") || !strcmp(word,"arrow") ||  !strcmp(word,"assign") || !strcmp(word,"if") || !strcmp(word,"while") || !strcmp(word,"for") || !strcmp(word,"sequence") || !strcmp(word,"intprint") || !strcmp(word,"stringprint") || !strcmp(word,"readint") ){
            lex->type = token_KEYWORD;      //keyword
        } else if (!strcmp(word,"None")){
            lex->type = token_INT;
            word = (char*) safe_realloc(word, maxbuff*sizeof(char));
            *word = '0';
            *(word+1)= '\0';
        } else {
            lex->type = token_NAME;     ///may or may not be a valid name token (that has been declared)
                                        ///check regex

        }
    }
    
    strcpy(lex->buffer, word);
    *(lex->buffer+lex->buff_len) = '\0';
    free(word);
}

int isValidName(char* name){
    //check that name matches regex
    return 0;
}


token_type peek_type(lexer *lex) {
    if (!lex) {
	return token_SENTINEL;
    }
    if (lex->type == token_SENTINEL) {
	read_token(lex);
    }
    return lex->type;
}

char *peek_value(lexer *lex) {
    if (!lex) {
	return NULL;
    }
    if (lex->type == token_SENTINEL) {
	read_token(lex);
    }
    return lex->buffer;
}

