#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include "lexer.h"
#include "util/util.h"
#include "parser.h"
#include <string.h>

#define INIT_BUFFER_SIZE 256

void init_lex(lexer *luthor) {
    luthor->file = NULL;
    luthor->buffer = NULL;
    luthor->type = token_SENTINEL;
    luthor->buff_len = 0;
}

void open_file(lexer *lex, char *filename) {
    if (lex) {
	lex->file = fopen(filename, "r");
	if (!lex->file) {
	    fatal_error("Could not read input file.\n");
	}
	lex->buff_len = INIT_BUFFER_SIZE;
	lex->buffer = safe_calloc(INIT_BUFFER_SIZE * sizeof(char));
    }
}

void close_file(lexer *lex) {
    if (lex) {
	fclose(lex->file);
	free(lex->buffer);
	lex->buff_len = 0;
	lex->buffer = NULL;
    }
}

void read_token(lexer *lex) {
    /* TODO: Implement me. */
    /* HINT: fgetc() and ungetc() could be pretty useful here. */
    lex->buffer = (char*) safe_realloc(lex->buffer, INIT_BUFFER_SIZE*sizeof(char));
    char* word = malloc(INIT_BUFFER_SIZE*sizeof(char));
    lex->buff_len=0;
    int maxbuff = INIT_BUFFER_SIZE;

    if (word == NULL){
        printf("allocation error\n");
    }
    char c;
    c = fgetc(lex->file);

    while (c=='\n' || c=='\t' || c== ' ') {
        c=fgetc(lex->file);     //move through white space until next char
    }

    if (c == '('){  //found non white char
        //*word=c;
        //strcat(word, "\0");
        *(lex->buffer)=c;
        *(lex->buffer+1)='\0';
        lex->type = token_OPEN_PAREN;
        lex->buff_len++;
    } else if (c == ')'){
        *word = c;
        //strcat(word,"\0");
        lex->type = token_CLOSE_PAREN;
        lex->buff_len++;
    } else if (c == EOF){
        *word = c;
        lex->type = token_END;
        lex->buff_len++;
    } else if (c > 47 && c < 58 ) {    //first character is a digit, so type is int
        lex->type = token_INT;
        while (c!='\n' && c!='\t' && c!= ' ' ){
            if (c<48 || c >57) {
                printf("Lexing Error: invalid integer token\n");
            } else {
                if (lex->buff_len >= maxbuff) {
                    //reallocate NEEDS DEBUGGING
                    maxbuff = maxbuff*2;
                    word = (char*) safe_realloc(word, maxbuff*sizeof(char));
                    lex->buffer = (char*) safe_realloc(lex->buffer, maxbuff*sizeof(char));
                }
                *(word+lex->buff_len)=c;
                lex->buff_len++;
                c=fgetc(lex->file);
            }
            //strcat(word ,"\0");
        }
    } else if (c=='\"') { //token is a LIFC string
        while ((c=fgetc(lex->file))!='\"') {
           if (lex->buff_len >= maxbuff) {
                //reallocate    NEEDS DEBUGGING
                maxbuff=maxbuff*2;
                word = (char*) safe_realloc(word, maxbuff*sizeof(char));
                lex->buffer = (char*) safe_realloc(lex->buffer, maxbuff*sizeof(char));
           } 
            *(word+lex->buff_len) = c;
            lex->buff_len++;
        }

        //strcat(word,"\0");
        lex->type = token_STRING;

    } else {        //token is a string keyword or name
        while (c!='\n' && c!='\t' && c!= ' ' ){
            if (lex->buff_len >= maxbuff) {
                //reallocate    NEEDS DEBUGGING
                maxbuff=maxbuff*2;    //double buffer
                word = (char*) safe_realloc(word, maxbuff*sizeof(char));
                lex->buffer = (char*) safe_realloc(lex->buffer, maxbuff*sizeof(char));
            } 
            *(word+lex->buff_len) = c;
            lex->buff_len++;
            c=fgetc(lex->file);
            
        }
        //strcat(word,"\0");

        if (!strcmp(word,"+") || !strcmp(word,"-") || !strcmp(word,"*") || !strcmp(word,"/")){
            //printf("keyword math\n");
            lex->type = token_KEYWORD;  //basic arithmetic
        } else if (!strcmp(word, "and") || !strcmp(word,"or") || !strcmp(word,"lt") || !strcmp(word,"eq") || !strcmp(word,"function") || !strcmp(word,"struct") || !strcmp(word,"arrow") || !strcmp(word,"None") || !strcmp(word,"assign") || !strcmp(word,"if") || !strcmp(word,"while") || !strcmp(word,"for") || !strcmp(word,"sequence") || !strcmp(word,"intprint") || !strcmp(word,"stringprint") || !strcmp(word,"readint") ){
            //printf("keyword func\n");
            lex->type = token_KEYWORD;      //keyword
        } else {
            //printf("name\n");
            lex->type = token_NAME;     ///may or may not be a valid name token, check in parser
        }
    }
    //printf("here3\n");
    strcpy(lex->buffer, word);
    free(word);
}

token_type peek_type(lexer *lex) {
    if (!lex) {
	return token_SENTINEL;
    }
    if (lex->type == token_SENTINEL) {
	read_token(lex);
    }
    return lex->type;
}

char *peek_value(lexer *lex) {
    if (!lex) {
	return NULL;
    }
    if (lex->type == token_SENTINEL) {
	read_token(lex);
    }
    return lex->buffer;
}

