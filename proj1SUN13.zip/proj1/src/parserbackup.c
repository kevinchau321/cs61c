#include "parser.h"
#include "lexer.h"
#include <string.h>
#include <stdlib.h>

/** An array of the different string values of keywords. */
char *keywords[] = {"and", "or", "+", "-", "*", "/", "lt", "eq", 
		    "function", "struct", "arrow", "assign", "if", 
		    "while", "for", "sequence", "intprint", "stringprint",
		    "readint"};
/** Sister array of keywords. Keeps track of the corresponding enum. */
int enums[] = {node_AND, node_OR, node_PLUS, node_MINUS, node_MUL, node_DIV,
	       node_LT, node_EQ, node_FUNCTION, node_STRUCT, 
	       node_ARROW, node_ASSIGN, node_IF, node_WHILE, node_FOR, 
	       node_SEQ, node_I_PRINT, node_S_PRINT, node_READ_INT};
/** A hashmap used for more efficient lookups of (keyword, enum) pairs. */
smap *keyword_str_to_enum;


/** Initializes keyword_str_to_enum so that it contains a map
 *  from the string value of a keyword to its corresponding enum. */
void initialize_keyword_to_enum_mapping();
void init_num_args();


void parse_init() {
    decls = smap_new();
    stack_sizes = smap_new();
    num_args = smap_new();
    strings = smap_new();
    keyword_str_to_enum = smap_new();
}

void parse_close() {
    smap_del_contents(decls);
    smap_del(decls);
    smap_del(stack_sizes);
    smap_del(num_args);
    smap_del(strings);
    smap_del(keyword_str_to_enum);
}

AST *build_ast (lexer *lex) {
    /* TODO: Implement me. */
    /* Hint: switch statements are pretty cool, and they work 
     *       brilliantly with enums. */
    AST* newAST = safe_calloc(sizeof(AST));
    init_AST(newAST);
    if (lex->type != token_OPEN_PAREN){
        fprintf(stderr, "Syntax Error: top level parenthetical expression is missing open parenthesis");
        exit(1);
    } else {            //first token is open paren, so build new tree
        while (lex->type != token_CLOSE_PAREN){
            read_token(lex);       //ADVANCE LEXER to get next token
            switch (lex->type) {
                case token_INT:         //INT
                    fprintf(stderr, "Syntax Error: Integer cannot start parenthetical expression, must be function or keyword\n");
                    exit(1);
                    break;
                case token_STRING:         //STRING
                    fprintf(stderr, "Syntax Error: String Literal cannot start parenthetical expression, must be function or keyword\n");
                    exit(1);
                    break;
                case token_NAME:         //NAME could be function call or variable. Only func will be valid syntax, check after declarations. this AST builder assumes the name is a func
                    newAST->type = node_CALL;
                    strcpy(newAST->val, lex->buffer);
                    AST_lst* currArg;                
                    while (peek_type(lex)!=token_CLOSE_PAREN){       //ADVANCE LEXER args could be int, string, var, or subexpression for call
                        switch (lex->type){                     ///Gather args and store as children of call ast node  
                            case token_INT:     //these are leaf nodes
                            case token_STRING:
                            case token_NAME:    //could be var name
                                if (newAST->children == NULL){      //no arg head yet
                                    AST_lst* firstArg = leafAST(lex);
                                    newAST->children = firstArg;
                                    currArg = firstArg;
                                } else {
                                    AST_lst* nextArg = leafAST(lex);
                                    currArg->next = nextArg;    //add arg ast lst to children of func name
                                    currArg = nextArg;          //move the current child pointer
                                }
                                break;
                            case token_OPEN_PAREN:            //sub:qexpression passed;
                                AST_lst *subExArgLst = NULL;
                                subExpArgLst = (AST_lst*) malloc(sizeof(AST_lst));
                                AST* subExp = build_AST(lex);
                                subExpArgLst->val = subExp;
                                if (newAST->children == NULL){
                                    AST->children = subExpArgLst;
                                    currArg = subExpArgLst; 
                                } else {
                                    currArg->next = subExpArgLst;
                                    currArg = subExpArgLst;
                                }
                                break;
                        }
                    }
                    if (newAST->children != NULL){
                        newAST->last_child = currArg;
                    }   
                    if (lex->type!=token_CLOSE_PAREN){     //could have zero args HANDLES PAREN ERRORS
                        printf(stderr, "Syntax Error: invalid function declaration; args must be names and end in close paren\n");
                        exit(1);
                    }                                    
                    break;
                case token_KEYWORD:         //KEYWORD
                    switch (lookup_keyword_enum(lex->buffer)){
                        case node_AND:          //ALL OF THE FOLLOWiNG ARE BINARY OPERATORS ONLY
                        case node_OR:
                        case node_PLUS:
                        case node_MINUS:
                        case node_MUL:
                        case node_DIV:
                        case node_LT:
                        case node_EQ:               ///could make a helper function to handle all binary operations
                            newAST->type = lookup_keyword_enum(lex->buffer);
                            strcpy(newAST->val, lex->buffer);
                            AST_lst firstOpLst = malloc(sizeof(AST_lst));
                            AST_lst secondOpLst = malloc(sizeof(AST_lst));

                            read_token(lex);        //ADVANCE LEXER read for op1
                            if (lex->type == token_OPEN_PAREN){      //operand is subtree
                                AST* op1 = build_AST(lex);
                            } else {        //make leaf AST NODE for int, variable name, string etc
                                AST* op1 = binOpLeaf(lex);
                            }
                            firstOpLst->val = op1;
                            newAST->children = firstOpLst;

                            read_token(lex);      //ADVANCE LEXER read for op2
                            if (lex->type == token_OPEN_PAREN){      //operand is subtree
                                AST* op2 = build_AST(lex);
                            } else {        //make leaf AST NODE
                                AST* op2 = binOpLeaf(lex);
                            }
                            secondOpLst->val = op2;
                            newAST->children->next = secondOpLst;

                            if (peek_type(lex) != token_CLOSE_PAREN) { ///ADVANCE LEXER token must be close paren
                                fprintf(stderr, "Syntax Error: Expression must end with a close parenthesis\n");
                                exit(1);
                            }                   
                            break;
                        case node_FUNCTION:
                            newAST->type = node_FUNCTION;
                            strcpy(newAST->val, lex->buffer);
                            if (peek_type(lex) != token_OPEN_PAREN){  //ADVANCE LEXER past function keyword, HANDLES ERRORS
                                fprintf(stderr, "Syntax Error: invalid function declaration, name and args must be within parenthetical\n");
                                exit(1); 
                            } else {        //first token after function keyword is open paren so move on
                                if (peek_type(lex) != token_NAME) { //ADVANCE LEXER and next token must be a name, HANDLES ERRORS
                                    fprintf(stderr, "Syntax Error: invalid function name declared\n");
                                    exit(1); 
                                } else {  //build function parenthetical
                                    AST* funcDeclAST = malloc(sizeof(AST));  //manually build declartion AST for easy decl identification
                                    init_AST(funcDeclAST);
                                    funcDeclAST->type = node_VAR;
                                    funcDeclAST->val = lex->buffer;
                                    //get argument names until close parenthesis, otherwise error
                                    AST_lst* currArg;
                                    while (peek_type(lex)==token_NAME){       //ADVANCE LEXER args must be names in declaration
                                        if (funcDeclAST->children = NULL){      //no arg head yet
                                            AST_lst* firstArg = leafAST(lex);
                                            funcDeclAST->children = firstArg;
                                            currArg = firstArg;
                                        } else {
                                            AST_lst* nextArg = leafAST(lex);
                                            currArg->next = nextArg;    //add arg ast lst to children of func name
                                            currArg = nextArg;          //move the current child pointer
                                        }
                                    }
                                    if (funcDeclAST->children != NULL){
                                        funcDeclAST->last_child = currArg;
                                    }
                                    if (lex->type!=token_CLOSE_PAREN){     //could have zero args HANDLES ERRORS
                                        fprintf(stderr, "Syntax Error: invalid function declaration; args must be names and end in close paren\n");
                                        exit(1);
                                    }
                                    newAST->children = funcDeclAST;     //append parenthetical declartion to function keyword newAST
                                    //build and apend ast tree for body
                                    read_token(lex);    //ADVANCE LEXER
                                    switch( lex->type ){
                                        case token_INT:
                                        case token_STRING:
                                        case token_NAME:        //has to be a variable
                                            AST_lst* singleToken = leafAST(lex);
                                            newAST->children->next = singleToken;
                                            newAST->last_child = singleToken;
                                            break;
                                        case token_OPEN_PAREN:        //function call or expression
                                            AST* bodyParens = build_AST(lex);       
                                            AST_lst* bodylst = malloc(sizeof(AST_lst));
                                            bodylst->val = bodyParens;
                                            newAST->children->next = bodylst;     //append body to declaration
                                            newAST->last_child = bodylst;   
                                            break;
                                        default:
                                            fprintf(stderr, "Syntax Error: invalid function body\n");
                                            exit(1);
                                            break;
                                    }
                                    if (peek_type(lex) != token_CLOSE_PAREN) { ///ADVANCE LEXER token must be close paren
                                        fprintf(stderr, "Syntax Error: Expression must end with a close parenthesis\n");
                                        exit(1);
                                    }     
                                }
                            }
                            break; 
                        case node_STRUCT:   //struct has same syntax as function call, subexpressions can be var name, int, string, or parenthetical
                            newAST->type = node_STRUCT;
                            strcpy(newAST->val, lex->buffer);
                            AST_lst* currField;                
                            while (peek_type(lex)!=token_CLOSE_PAREN){       //ADVANCE LEXER args could be int, string, var, or subexpression for call
                                switch (lex->type){                     ///Gather args and store as children of call ast node  
                                    case token_INT:     //these are leaf nodes
                                    case token_STRING:
                                    case token_VAR:
                                        if (newAST->children == NULL){      //no arg head yet
                                            AST_lst* firstField = leafAST(lex);
                                            newAST->children = firstField;
                                            currField = firstField;
                                        } else {
                                            AST_lst* nextField = leafAST(lex);
                                            currField->next = nextField;    //add arg ast lst to children of func name
                                            currField = nextField          //move the current child pointer
                                        }
                                        break;
                                    case token_OPEN_PAREN:            //subexpression passed;
                                        AST_lst* subExpFieldLst = malloc(sizeof(AST_lst));
                                        AST* subExpField = build_AST(lex);
                                        subExpArgLst->val = subExpField;
                                        if (newAST->children == NULL){
                                            AST->children = subExpFieldLst;
                                            currField = subExpFieldLst; 
                                        } else {
                                            currField->next = subExpFieldLst;
                                            currField = subExpFieldLst;
                                        }
                                        break;
                                }
                            }
                            if (newAST->children != NULL){
                                newAST->last_child = currField;
                            }   
                            if (lex->type!=token_CLOSE_PAREN){     //could have zero args HANDLES PAREN ERRORS
                                printf(stderr, "Syntax Error: invalid function declaration; args must be names and end in close paren\n");
                                exit(1);
                            }                                    
                            break;
                        case node_ARROW:    //can take struct variable name or struct sub expression
                            newAST->type = node_ARROW;
                            strcpy(newAST->val, lex->buffer);
                            read_token(lex);        //ADVANCE THE TOKEN TO CHECK FOR VAR OR OPEN PAREN FOR STRUCT
                            if (lex->type==toke_NAME){
                                AST_lst* varNode = leafAST(lex);
                                newAST->children = varNode;     //struct name is first child or node ARROW
                                if (peek_type(lex)!=token_INT){         //get struct index
                                    fprintf(stderr, "arrow to struct field must have integer index\n");
                                    exit(1);
                                } 
                                AST_lst* indexNode = leafAST(lex);
                                newAST->children->next= indexNode;
                            } else if (lex->type == token_OPEN_PAREN) {
                                AST* structASTNode = build_AST(lex);
                                AST_lst* structLst = malloc(sizeof(AST_lst));
                                structLst->val = structASTNode;
                                newAST->children->next = structLst;
                            } else {
                                fprintf(stderr, "arrow must point to struct name or struct expression\n");
                                exit(1);
                            }
                            if (peek_type(lex)!=token_CLOSE_PAREN){     //HANDLES PAREN ERRORS
                                printf(stderr, "Syntax Error: invalid function declaration; args must be names and end in close paren\n");
                                exit(1);
                            }   
                            break; 
                        case node_ASSIGN:
                            newAST->type = node_ASSIGN;
                            strcpy(newAST->val, lex->buffer);
                            if (peek_type(lex)!=token_NAME) {   //token after assign must be var name
                                fprint(stderr, "Syntax Error: assign takes variable name arg\n");
                                exit(1);
                            }
                            AST_lst* varName = leafAST(lex);
                            newAST->children = varName;
                            switch (peek_type(lex)){    //make ast lst for int, string, struct
                                case token_INT:
                                case token_STRING:
                                    AST_lst* val = leafAST(lex);
                                    newAST->children->next=val;
                                    newAST->last_child->val;
                                    break;
                                case token_OPEN_PAREN:        //open paren is for struct assign
                                    AST_lst* structASTLst = malloc(sizeof(AST_lst));
                                    AST* structAST = build_AST(lex);
                                    structASTLST->val = structAST;
                                    newAST->children->next = structASTLST;
                                    newAST->last_child->structASTLST;
                                    break;
                            }
                            if (peek_type(lex)!=token_CLOSE_PAREN){     //HANDLES PAREN ERROR
                                printf(stderr, "Syntax Error: invalid function declaration; args must be names and end in close paren\n");
                                exit(1);
                            } 
                            break;
                        case node_IF:       //all three sub expressions could be var, int, string (no parens) or parenthetical sub expression (struct, call, or eval)
                            newAST->type = node_IF;
                            strcpy(newAST->val, lex->buffer);
                            int expCount = 0;
                            AST_lst* currExp;
                            while (expCount<3){
                                read_token(lex);
                                AST_lst* subExLst = getSubExLst(lex);
                                if (newAST->children == NULL){
                                    newAST->children = subExLst;
                                    currExp = subExLst;
                                } else {
                                    currExp->next = subExLst;
                                    currExp = subExLst;
                                }
                                expCount++;
                            }
                            if (peek_type(lex)!=token_CLOSE_PAREN){     //HANDLES PAREN ERROR
                                printf(stderr, "Syntax Error: if statement\n");
                                exit(1);
                            }
                            if (newAST->children != NULL){
                                newAST->last_child = currExp;
                            }    
                            break; 
                        case node_WHILE:
                            newAST->type = node_WHILE;
                            strcpy(newAST->val, lex->buffer);
                            int expCount = 0;
                            AST_lst* currExp;
                            while (expCount<2){
                                read_token(lex);
                                AST_lst* subExLst = getSubExLst(lex);
                                if (newAST->children == NULL){
                                    newAST->children = subExLst;
                                    currExp = subExLst;
                                } else {
                                    currExp->next = subExLst;
                                    currExp = subExLst;
                                }
                                expCount++;
                            }
                            if (peek_type(lex)!=token_CLOSE_PAREN){     //HANDLES PAREN ERROR
                                printf(stderr, "Syntax Error: if statement\n");
                                exit(1);
                            }
                            if (newAST->children != NULL){
                                newAST->last_child = currExp;
                            } 
                            break;
                        case node_FOR:
                            newAST->type = node_FOR;
                            strcpy(newAST->val, lex->buffer);
                            int expCount = 0;
                            AST_lst* currExp;
                            while (expCount<4){
                                read_token(lex);
                                AST_lst* subExLst = getSubExLst(lex);
                                if (newAST->children == NULL){
                                    newAST->children = subExLst;
                                    currExp = subExLst;
                                } else {
                                    currExp->next = subExLst;
                                    currExp = subExLst;
                                }
                                expCount++;
                            }
                            if (peek_type(lex)!=token_CLOSE_PAREN){     //HANDLES PAREN ERROR
                                printf(stderr, "Syntax Error: if statement\n");
                                exit(1);
                            }
                            if (newAST->children != NULL){
                                newAST->last_child = currExp;
                            }
                            break;
                        case node_SEQ:
                            newAST->type = node_SEQ;
                            strcpy(newAST->val, lex->buffer);
                            int expCount = 0;
                            AST_lst* currExp;
                            while (peek_type(lex)!=token_CLOSE_PAREN){
                                AST_lst* subExLst = getSubExLst(lex);
                                if (newAST->children == NULL){
                                    newAST->children = subExLst;
                                    currExp = subExLst;
                                } else {
                                    currExp->next = subExLst;
                                    currExp = subExLst;
                                }
                                expCount++;
                            }
                            if (newAST->children != NULL){
                                newAST->last_child = currExp;
                            } 
                            break;
                        case node_I_PRINT: 
                            newAST->type = node_I_PRINT;
                            strcpy(newAST->val, lex->buffer);
                            if (peek_type(lex) != token_INT){       //ADVANCE THE LEXER TO CHECK FOR INT
                                fprintf(stderr, "Syntax Error: intprint can only print integer\n");
                                exit(1);
                            }
                            AST_lst* printedInt = leafAST(lex); 
                            newAST->children = printedInt;
                            newAST->last_child = printedInt;    ///these continue without break to read int which checks for close paren
                        case node_S_PRINT:
                            newAST->type = node_S_PRINT;
                            strcpy(newAST->val, lex->buffer);
                            if (peek_type(lex) != token_STRING){       //ADVANCE THE LEXER TO CHECK TO STRING
                                fprintf(stderr, "Syntax Error: stringprint can only print integer\n");
                                exit(1);
                            }
                            AST_lst* printedString = leafAST(lex); 
                            newAST->children = printedString;
                            newAST->last_child = printedString;
                        case node_READ_INT:
                            newAST->type = node_READ_INT;
                            strcpy(newAST->val, lex->buffer);
                            if (peek_type(lex) != token_CLOSE_PAREN) { ///ADVANCE LEXER token must be close paren
                                fprintf(stderr, "Syntax Error: Expression must end with a close parenthesis\n");
                                exit(1);
                            }  
                            break;
                        default:
                            //some type of error handling here may be necessary
                            break;
                    }
                case token_OPEN_PAREN:         //OPEN, syntax error most likely an attempt to start expression with a sub expression parenthetical
                case token_CLOSE_PAREN:         //CLOSE
                case token_END:         //END
                case token_SENTINEL:         //SENTINEL
                default:
                    fprintf(stderr, "Syntax Error: Bad expression following open paren\n");
                    exit(1);
                    break;
            }
        }
    }   
}

//takes the token currently in lex, assuming it is a leaf node
AST* binOpLeaf(lexer* lex){ 
    AST* op = malloc(sizeof(AST));
    init_AST(op);
    switch(lex->type){
        case token_NAME:       //token must be a var not func name, otherwise its invalid. check syntax after gathering declarations   
            op->type = node_VAR;      ///can't be func, but parser will need to handle 
            break;
        case token_STRING:
            op->type = node_STRING;
            break;
        case token_INT:
            op->type = node_INT;
            break;
        default: 
            fprintf(stderr,"Syntax Error: invalid binary operand\n");
            break;
    }
    op->val = lex->buffer;
    return op;
}
AST_lst* leafAST(lexer* lex){
    AST_lst* lstLeaf = malloc(sizeof(AST_lst));
    AST* leaf = malloc(sizeof(AST));     //children are null, since leafAST is a leaf
    init_AST(leaf);
    switch (lex->type){
        case token_INT:
            leaf->type = node_INT;
            break;
        case token_STRING:
            leaf->type = node_STRING;
            break;
        case token_NAME:
            leaf->type = node_VAR;       //has to be variable name, otherwise invalid
            break;
        case token_KEYWORD:
            if (lex->buffer == "None"){
                leaf->type = node_INT;     //None is equivalent to 0
            } else {
                fprintf(stderr,"Syntax Error keyword cannot be leaf\n");
                exit(1);
            }
            break;
    }
    leaf->val = lex->buffer;
    lstLeaf->val = leaf;
    return lstLeaf;
}
AST_lst* getSubExLst(lexer* lex){
    switch(lex->type){
        case token_INT:
        case token_STRING:
        case token_NAME:            //var name
            break;
            AST_lst* leaf = leafAST(lex);
            return leaf;
        case token_OPEN:
            AST* subParen = build_AST(lex);
            AST_lst* subParenLst = malloc(sizeof(AST_lst));
            subParenLst->val = subParen;
            return subParenLst;
        default:
            fprintf(stderr, "Syntax Error: invalid subexpression\n");
            exit(1);
            break;
    }
}
void init_AST(AST *initAST){
    initAST->type = NULL;
    initAST->val= NULL;
    initAST->children = NULL;
    initAST->last_child=NULL;
}

void free_ast (AST *ptr) {
    /* TODO: Implement me. */
}

void check_tree_shape(AST *ptr) {
    /* TODO: Implement me. */
    /* Hint: This function is just asking to be table-driven */
    ..


}

void gather_decls(AST *ast, char *env, int is_top_level) {
    /* TODO: Implement me. */
    /* Hint: switch statements are pretty cool, and they work 
     *       brilliantly with enums. */
}

type lookup_keyword_enum(char *str) {
    if (smap_get(keyword_str_to_enum, keywords[0]) == -1) {
	initialize_keyword_to_enum_mapping();
    }
    return smap_get(keyword_str_to_enum, str);
}

void initialize_keyword_to_enum_mapping() {
    /* Note that enums is an *array*, not a pointer, so this
     * sizeof business is reasonable. */
    size_t num_keywords = sizeof(enums) / sizeof(int); 
    for (size_t i = 0; i < num_keywords; i += 1) {
	smap_put(keyword_str_to_enum, keywords[i], enums[i]);
    }
}
void init_num_args(){
    //stores number of appropriate args or operands/ nodes. If the buffer isn't in the hash map, will return -1 so up to tree check to determine number of args
    smap_put(num_args, "and", 2);
    smap_put(num_args, "or", 2);
    smap_put(num_args, "+", 2);
    smap_put(num_args, "-", 2);
    smap_put(num_args, "*", 2);
    smap_put(num_args, "/", 2);
    smap_put(num_args, "lt", 2);
    smap_put(num_args, "eq", 2);
    smap_put(num_args, "function", 2);      //function declaration
    smap_put(num_args, "arrow", 2);
    smap_put(num_args, "assign", 2);
    smap_put(num_args, "if", 3);
    smap_put(num_args, "while", 2);
    smap_put(num_args, "for", 4);
    smap_put(num_args, "intprint", 1);
    smap_put(num_args, "stringprint", 1);
    smap_put(num_args, "readint", 0);
}

size_t AST_lst_len(AST_lst *lst) {
    int num_fields = 0;
    while (lst) {
	num_fields += 1;
	lst = lst->next;
    }
    return num_fields;
}

int valid_name(char* s){       //match to regex
    return 0;
}

smap *decls;
smap *stack_sizes;
smap *num_args;
smap *strings;
