//Tests
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include "lexer.h"
#include "util/util.h"
#include "parser.h"


//aim for roughly 45 program tests
int main(int argc, char* argv[]){
    lexer *lex1 = malloc(sizeof(lexer));
    init_lex(lex1);
    open_file(lex1,argv[1]);
    while (lex1->type != 6){
    	read_token(lex1);
    	printf("buffer string is: %s\n", lex1->buffer);
    	printf("buffer type (enum) is: %d\n", lex1->type);
    }
    return 0;
}